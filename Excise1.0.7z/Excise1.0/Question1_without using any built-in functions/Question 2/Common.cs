﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    public static class Common
    {
        public static int[] InputInfo = { 1, 5, 1, 1, 3, 9 };
        public static int[] InputParam = { 1, 3, 5, 4, 6 };
    }
}
