﻿using Question_2;
using System;
using System.Collections.Generic;

public class Program
{
 /// <summary>
 /// 
 /// </summary>
 /// <param name="a"></param>
 /// <param name="b"></param>
 /// <returns></returns>
    public static Dictionary<int, int> merge_counter(int[] a, int[] b)
    {
        Dictionary<int, int> result = new Dictionary<int, int>();

        // Determine the maximum length between the two arrays
        int maxLength = Math.Max(a.Length, b.Length);

        for (int i = 0; i < maxLength; i++)
        {
            // Check if index is within bounds for array a
            if (i < a.Length)
            {
                if (result.ContainsKey(a[i]))
                {
                    result[a[i]]++;
                }
                else
                {
                    result.Add(a[i], 1);
                }
            }

            // Check if index is within bounds for array b
            if (i < b.Length)
            {
                if (result.ContainsKey(b[i]))
                {
                    result[b[i]]++;
                }
                else
                {
                    result.Add(b[i], 1);
                }
            }
        }

        return result;
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="args"></param>
    public static void Main(string[] args)
    {
        Dictionary<int, int> result = merge_counter(Common.InputInfo, Common.InputParam);

        foreach (var pair in result)
        {
            Console.WriteLine($"{pair.Key}: {pair.Value}");
        }
    }
}
