﻿// See https://aka.ms/new-console-template for more information
using System.Runtime.InteropServices;
using System;

using System;
using Question1_without_using_any_built_in_functions;

class Question1
{
    static void Main()
    {
        // Example usage
        Console.WriteLine(Ita(Common.positive, 2));  // Output: 10011010010
        Console.WriteLine(Ita(Common.Negative, 16));  // Output: FFFFFB2E
    }

    static string Ita(int value, int baseNum)
    {
        if (baseNum < 2 || baseNum > 36)
        {
            throw new ArgumentException("Invalid base. Base should be between 2 and 36.");
        }

       
        string result = "";

        bool isNegative = false;
        if (value < 0)
        {
            isNegative = true;
            value = -value;
        }

        if (value == 0)
        {
            return "0";
        }

        while (value > 0)
        {
            int remainder = value % baseNum;
            result = Common.digits[remainder] + result;
            value /= baseNum;
        }

        if (isNegative)
        {
            if (baseNum == 16)
            {
                // For hexadecimal, we represent negative numbers as their two's complement
                // in a 32-bit representation, which is FFFFFFFF for -1, FFFFFFEE for -2, etc.
                // However, since we're dealing with a string representation and not actual binary,
                // we'll simply prefix with FFFF... to indicate a negative value in a way that's
                // consistent with the example output.
                result = new string('F', 8 - result.Length) + result;
            }
            else
            {
                // For other bases, simply prefix with a minus sign
                result = "-" + result;
            }
        }

        return result;
    }
}

