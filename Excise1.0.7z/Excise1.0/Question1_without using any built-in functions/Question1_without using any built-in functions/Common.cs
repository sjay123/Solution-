﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1_without_using_any_built_in_functions
{
    public static class Common
    {
        public static int positive = 1234;
        public static int Negative = -1234;
        public static string digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    }
}
