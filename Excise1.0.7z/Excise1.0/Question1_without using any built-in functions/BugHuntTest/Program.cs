﻿using System;

namespace BugHuntTest
{
    class Program
    {
        static void Main(string[] args)
        {
            List list = new List();
            list.AddHead(1);
            list.Add(2);
            list.Add(3);
            list.Add(4);
            list.PrintAll();
            list.Delete(2);
            list.PrintAll();
            Console.WriteLine($"Last Node: {list.Last()?.Data}");
            Console.WriteLine($"Length: {list.Length}");
        }
    }
    /// <summary>
    /// 
    /// </summary>
    public class Node
    {
        public object Data { get; set; }
        public Node Next { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class List
    {
        public Node Head { get; private set; }

        // Adds a head element
        public void AddHead(object data)
        {
            Node newNode = new Node { Data = data, Next = Head };
            Head = newNode;
        }

        // Adds an element to the end of the list
        public void Add(object data)
        {
            if (Head == null)
            {
                AddHead(data);
                return;
            }

            var current = Head;
            while (current.Next != null)
            {
                current = current.Next;
            }

            current.Next = new Node { Data = data };
        }

        // Prints all elements to the console
        public void PrintAll()
        {
            var current = Head;
            while (current != null)
            {
                Console.WriteLine(current.Data);
                current = current.Next;
            }
            Console.WriteLine();
        }

        // Returns the last element in the list
        public Node Last()
        {
            if (Head == null) return null;

            var current = Head;
            while (current.Next != null)
            {
                current = current.Next;
            }

            return current;
        }

        // Deletes the nth element in the list
        public void Delete(int n)
        {
            if (Head == null || n < 0) throw new ArgumentOutOfRangeException("Invalid index");

            if (n == 0)
            {
                Head = Head.Next;
                return;
            }

            var current = Head;
            for (int i = 0; i < n - 1; i++)
            {
                if (current.Next == null) throw new ArgumentOutOfRangeException("Index out of bounds");
                current = current.Next;
            }

            if (current.Next != null)
                current.Next = current.Next.Next;
        }

        // Insert element at position
        public void Insert(int pos, object data)
        {
            if (pos < 0) throw new ArgumentOutOfRangeException("Invalid position");

            if (pos == 0)
            {
                AddHead(data);
                return;
            }

            var current = Head;
            for (int i = 0; i < pos - 1; i++)
            {
                if (current == null) throw new ArgumentOutOfRangeException("Position out of bounds");
                current = current.Next;
            }

            var newNode = new Node { Data = data, Next = current?.Next };
            current.Next = newNode;
        }

        // Locate the node for given data
        public Node Find(object data)
        {
            var current = Head;

            while (current != null)
            {
                if (current.Data.Equals(data))
                    return current;

                current = current.Next;
            }

            return null;
        }

        // Returns the length of the list
        public int Length
        {
            get
            {
                int count = 0;
                var current = Head;

                while (current != null)
                {
                    count++;
                    current = current.Next;
                }

                return count;
            }
        }
    }
}
